const json = (data, status = 200, headers = {}) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", ...headers } });
const now = () => Date.now();
const withinUK = (lat, lon) => Number.isFinite(lat) && Number.isFinite(lon) && lat >= 49 && lat <= 61.5 && lon >= -9 && lon <= 3;
async function hashDevice(raw, salt) {
  const bytes = new TextEncoder().encode(`${String(raw || "anonymous").slice(0,100)}${salt || "cam-alert-uk"}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2,"0")).join("");
}
async function cleanExpired(db) {
  await db.prepare("UPDATE reports SET status='expired' WHERE expires_at < ? AND status='active'").bind(now()).run();
}
async function handleApi(request, env, url) {
  const db = env.DB;
  const ua = env.NOMINATIM_USER_AGENT || "CamAlertUK/1.0 (contact: set-your-contact-email@example.com)";
  const path = url.pathname;

  if (path === "/api/health" && request.method === "GET")
    return json({ ok: true, app: "Cam Alert UK", database: "D1" });

  if (path === "/api/geocode" && request.method === "GET") {
    const q = (url.searchParams.get("q") || "").trim().slice(0,120);
    if (q.length < 3) return json([]);
    try {
      const u = new URL("https://nominatim.openstreetmap.org/search");
      u.search = new URLSearchParams({ q, format:"jsonv2", limit:"6", countrycodes:"gb", addressdetails:"1" });
      const r = await fetch(u, { headers: { "User-Agent":ua, "Accept-Language":"en-GB,en;q=0.8" } });
      if (!r.ok) throw new Error("Geocoder unavailable");
      const rows = await r.json();
      return json(rows.map(x => ({ name:x.display_name, lat:Number(x.lat), lon:Number(x.lon) })), 200,
        { "cache-control":"public, max-age=60" });
    } catch { return json({ error:"UK destination search is temporarily unavailable." },502); }
  }

  if (path === "/api/cameras" && request.method === "GET") {
    const south=Number(url.searchParams.get("south")), west=Number(url.searchParams.get("west"));
    const north=Number(url.searchParams.get("north")), east=Number(url.searchParams.get("east"));
    if (![south,west,north,east].every(Number.isFinite) || south<49 || north>61.5 || west< -9 || east>3 ||
      north<=south || east<=west || north-south>0.35 || east-west>0.45)
      return json({error:"Invalid or oversized UK map area."},400);
    const query=`[out:json][timeout:20];(nwr["highway"="speed_camera"](${south},${west},${north},${east});nwr["enforcement"="average_speed"](${south},${west},${north},${east}););out center tags;`;
    try {
      const r=await fetch("https://overpass-api.de/api/interpreter",{method:"POST",headers:{
        "Content-Type":"application/x-www-form-urlencoded;charset=UTF-8","User-Agent":ua},body:"data="+encodeURIComponent(query)});
      if(!r.ok) throw new Error("Overpass unavailable");
      const data=await r.json(), seen=new Set();
      const cams=(data.elements||[]).map(el=>{
        const lat=el.lat??el.center?.lat, lon=el.lon??el.center?.lon;
        if(!Number.isFinite(lat)||!Number.isFinite(lon)) return null;
        const tags=el.tags||{}, key=`${lat.toFixed(5)},${lon.toFixed(5)},${tags.enforcement||tags.highway||""}`;
        if(seen.has(key)) return null; seen.add(key);
        const raw=tags.maxspeed||tags["maxspeed:conditional"]||tags["maxspeed:forward"]||"";
        const m=String(raw).match(/(\d{1,3})/); let limit=m?Number(m[1]):null;
        if(limit&&/km\/?h/i.test(String(raw))) limit=Math.round(limit*.621371);
        return {id:`${el.type}-${el.id}`,lat,lon,kind:tags.enforcement==="average_speed"?"average":"fixed",
          limit:limit&&limit>=10&&limit<=100?limit:null,direction:tags.direction||tags.camera_direction||null,
          name:tags.name||(tags.enforcement==="average_speed"?"Average speed zone":"Speed camera")};
      }).filter(Boolean);
      return json(cams,200,{"cache-control":"public, max-age=120"});
    } catch { return json({error:"Camera data is temporarily unavailable from OpenStreetMap."},502); }
  }

  if (path === "/api/reports" && request.method === "GET") {
    await cleanExpired(db);
    const lat=Number(url.searchParams.get("lat")), lon=Number(url.searchParams.get("lon"));
    const {results=[]}=await db.prepare(`SELECT id,kind,lat,lon,note,created_at,expires_at,still_votes,gone_votes
      FROM reports WHERE status='active' AND expires_at>?`).bind(now()).all();
    const filtered=withinUK(lat,lon)?results.filter(x=>Math.abs(x.lat-lat)<.35&&Math.abs(x.lon-lon)<.45):results;
    return json(filtered);
  }

  if (path === "/api/reports" && request.method === "POST") {
    let body; try { body=await request.json(); } catch { return json({error:"Invalid JSON."},400); }
    const {kind,lat,lon,note=""}=body||{};
    if(!["mobile_camera","temporary_camera","hazard"].includes(kind)||!withinUK(lat,lon))
      return json({error:"Please send a valid UK report."},400);
    const device=await hashDevice(request.headers.get("x-device-id"),env.RATE_SALT);
    const cutoff=now()-3600000;
    await db.prepare("DELETE FROM rate_events WHERE created_at < ?").bind(cutoff).run();
    const count=await db.prepare("SELECT COUNT(*) AS n FROM rate_events WHERE device_hash=? AND created_at>?").bind(device,cutoff).first();
    if((count?.n||0)>=3) return json({error:"Report limit reached. Please try again later."},429);
    const id=crypto.randomUUID(), t=now(), expires=t+90*60*1000;
    await db.batch([
      db.prepare("INSERT INTO rate_events(device_hash,created_at) VALUES(?,?)").bind(device,t),
      db.prepare(`INSERT INTO reports(id,kind,lat,lon,note,created_at,expires_at,device_hash)
        VALUES(?,?,?,?,?,?,?,?)`).bind(id,kind,lat,lon,String(note).slice(0,100),t,expires,device)
    ]);
    return json({id,expires_at:expires},201);
  }

  const voteMatch=path.match(/^\/api\/reports\/([a-f0-9-]+)\/vote$/i);
  if(voteMatch && request.method==="POST") {
    let body; try { body=await request.json(); } catch { return json({error:"Invalid JSON."},400); }
    const vote=body?.vote;
    if(!["still","gone"].includes(vote)) return json({error:"Invalid vote."},400);
    await cleanExpired(db);
    const id=voteMatch[1], t=now();
    const report=await db.prepare("SELECT id FROM reports WHERE id=? AND status='active' AND expires_at>?").bind(id,t).first();
    if(!report) return json({error:"This report has expired or been removed."},404);
    const device=await hashDevice(request.headers.get("x-device-id"),env.RATE_SALT);
    try {
      await db.prepare("INSERT INTO votes(report_id,device_hash,vote,created_at) VALUES(?,?,?,?)").bind(id,device,vote,t).run();
    } catch { return json({error:"You've already voted on this report."},409); }
    const col=vote==="gone"?"gone_votes":"still_votes";
    await db.prepare(`UPDATE reports SET ${col}=${col}+1 WHERE id=?`).bind(id).run();
    const updated=await db.prepare("SELECT gone_votes,still_votes FROM reports WHERE id=?").bind(id).first();
    if(updated.gone_votes>=3 && updated.gone_votes>updated.still_votes)
      await db.prepare("UPDATE reports SET status='removed' WHERE id=?").bind(id).run();
    return json({ok:true,...updated});
  }

  if(path==="/api/route" && request.method==="GET") {
    const coords=url.searchParams.get("coords")||"";
    if(!/^-?\d+(\.\d+)?,-?\d+(\.\d+)?;/.test(coords)||coords.length>180)
      return json({error:"Invalid route coordinates."},400);
    try {
      const r=await fetch(`https://router.project-osrm.org/route/v1/driving/${coords}?overview=full&geometries=geojson&steps=true&alternatives=true`,
        {headers:{"User-Agent":ua}});
      if(!r.ok) throw new Error("OSRM unavailable");
      return json(await r.json(),200,{"cache-control":"no-store"});
    } catch { return json({error:"Routing is temporarily unavailable."},502); }
  }
  return json({error:"Not found."},404);
}

export default {
  async fetch(request, env) {
    const url=new URL(request.url);
    if(url.pathname.startsWith("/api/")) return handleApi(request,env,url);
    return env.ASSETS.fetch(request);
  }
};
