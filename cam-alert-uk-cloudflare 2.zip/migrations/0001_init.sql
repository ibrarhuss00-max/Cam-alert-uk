CREATE TABLE IF NOT EXISTS reports (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  lat REAL NOT NULL,
  lon REAL NOT NULL,
  note TEXT DEFAULT '',
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  device_hash TEXT NOT NULL,
  still_votes INTEGER NOT NULL DEFAULT 0,
  gone_votes INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active'
);
CREATE INDEX IF NOT EXISTS idx_reports_active_expiry ON reports(status, expires_at);
CREATE TABLE IF NOT EXISTS votes (
  report_id TEXT NOT NULL,
  device_hash TEXT NOT NULL,
  vote TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  PRIMARY KEY(report_id, device_hash)
);
CREATE TABLE IF NOT EXISTS rate_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  device_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rate_events_device_time ON rate_events(device_hash, created_at);
