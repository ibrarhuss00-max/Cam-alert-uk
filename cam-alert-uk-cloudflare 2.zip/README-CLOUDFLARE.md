# Cam Alert UK — Cloudflare edition

This edition replaces Express + local SQLite with a Cloudflare Worker + Cloudflare D1.
The browser app remains in `public/`.

## Free deployment outline

You need a free Cloudflare account and a GitHub account. Cloudflare may ask you to verify your account or payment method; check the plan and usage limits shown in your dashboard before enabling paid features.

### 1. Create the D1 database

1. In Cloudflare, open **Storage & databases → D1 SQL Database** (the menu may be labelled **D1**).
2. Choose **Create database**, name it `cam-alert-uk-db`.
3. Open the database's **Settings** and copy its database ID.
4. Replace `PASTE_YOUR_D1_DATABASE_ID_HERE` in `wrangler.toml` with that exact ID.
5. Open the database's **Console** and run the complete SQL in `migrations/0001_init.sql`.

### 2. Put this project in GitHub

1. Create a new private or public GitHub repository called `cam-alert-uk`.
2. Upload the contents of this ZIP to the repository root (not the ZIP file itself).
3. Commit the files.

### 3. Connect Cloudflare

1. In Cloudflare, open **Workers & Pages** and choose **Create** → **Workers** → **Import a repository** (wording can vary).
2. Connect GitHub and select `cam-alert-uk`.
3. Use the project root as the working directory.
4. Set the deploy command to `npm install && npx wrangler deploy`.
5. Deploy. The `wrangler.toml` file configures the static files and D1 binding.

If the dashboard asks for a build command, leave it blank unless it requires one. The deploy command above installs Wrangler and deploys the Worker.

### 4. Set your contact email

Edit `NOMINATIM_USER_AGENT` in `wrangler.toml` to include a real contact email before public use, then commit and push the change. Nominatim requires a descriptive User-Agent and applies a strict usage policy.

### 5. Test

Open the `workers.dev` address Cloudflare gives you. Check:
- `/api/health` returns `{"ok":true,...}`
- the home page loads over HTTPS
- allow location and test GPS only while parked
- camera lookup, destination search, routing and report submission work

## Notes and limitations

- The app depends on public OpenStreetMap tile, Overpass, Nominatim and OSRM services. They have independent fair-use policies, rate limits and availability; this is not guaranteed free unlimited infrastructure.
- Community reports are stored in D1. Reports expire after 90 minutes; three independent "Gone" votes remove a report. The API applies a basic per-device limit, but browser device IDs can be changed and are not strong identity verification.
- Camera data may be incomplete or inaccurate. Do not rely on this app instead of road signs or your judgement.
- Public OSRM routing has no guaranteed M6 Toll avoidance. The existing app only displays a heuristic note if route steps mention M6 Toll.
- The app is a starter, not a certified navigation or enforcement-warning product. Test thoroughly before use. Do not operate or interact with it while driving.
- This project is designed for Cloudflare Workers + D1; it is not a Replit project.
